#!/bin/bash

set -e

cd modules
python3 handshake2.py FACTFACT
cd ..
